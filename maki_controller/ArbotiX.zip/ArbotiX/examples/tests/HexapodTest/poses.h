#ifndef POSES
#define POSES

#include <avr/pgmspace.h>

const PROGMEM uint16_t Center[] = {18, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512};

#endif
