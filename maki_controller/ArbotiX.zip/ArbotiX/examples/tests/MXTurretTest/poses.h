#ifndef POSES
#define POSES

#include <avr/pgmspace.h>

const PROGMEM uint16_t Center[] = {2, 2048, 2048};
const PROGMEM uint16_t Home[] = {2, 2048, 2048};

#endif
